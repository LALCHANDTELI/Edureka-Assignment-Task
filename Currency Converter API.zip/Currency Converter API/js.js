//fetch api for filling options
fetch('https://api.exchangeratesapi.io/latest?base=USD').then((apiData) => {
        console.log(apiData);
        return apiData.json();
    }).then((Data) => {
        for (City in Data.rates) {
            var fromSelector = document.getElementById("fromId");
            var fromOption = document.createElement("option");
            fromOption.append(City);
            fromSelector.appendChild(fromOption);

            var toSelector = document.getElementById("toId");
            var toOption = document.createElement("option");
            toOption.append(City);
            toSelector.appendChild(toOption);
        }

    })
    //catch error if api not fetch data
    .catch((error) => {
        document.getElementById("info").removeAttribute("hidden");
        setTimeout(() => {
            document.getElementById("info").setAttribute("hidden", "");
        }, 3000);
    });

//for remove select_2 option that is already selected in select_1
let changeTo = () => {
    var userFrom = document.getElementById("fromId");
    document.getElementById("toId").remove(userFrom.selectedIndex);
}

//for remove select_1 option that is already selected in select_2
let changeFrom = () => {
    var userTo = document.getElementById("toId");
    document.getElementById("fromId").remove(userTo.selectedIndex);
}



//converting currency
let convert = () => {

    let userFrom = document.getElementById("fromId");
    let fromOption = userFrom.options[userFrom.selectedIndex].value;
    let userTo = document.getElementById("toId");
    let toOption = userTo.options[userTo.selectedIndex].value;
    let userAmount = document.getElementById("userAmount").value;
    //checking user amount > 0 
    if (userAmount > 0) {
        var actualUrl = 'https://api.exchangeratesapi.io/latest?base=';
        //again fetch api there is base currency is selected by user
        fetch(`${actualUrl}${fromOption}`, { method: 'GET' })
            .then((response) => response.json())
            .then((dataApi) => {
                //getting data and converting currency
                var final = dataApi.rates[toOption];
                final = final * Number(userAmount);
                //showing results
                document.getElementById("final-amount-msg").removeAttribute("hidden");
                document.getElementById("user-amount").innerHTML = userAmount;
                document.getElementById("msg").innerHTML = `${fromOption} is`;
                document.getElementById("final-amount").innerHTML = final;
                document.getElementById("msg2").innerHTML = toOption;





            })
    } else {
        //if else api data not fetch then showing warning for 3 seconds
        document.getElementById("warning").removeAttribute("hidden");
        setTimeout(() => {
            document.getElementById("warning").setAttribute("hidden", "");
        }, 3000);
    }




}