//fetch api for filling options
fetch('https://api.exchangeratesapi.io/latest?base=').then((apiData) => {
        console.log(apiData);
        return apiData.json();
    }).then((Data) => {
        for (City in Data.rates) {
            var fromSelector = document.getElementById("fromId");
            var fromOption = document.createElement("option");
            fromOption.append(City);
            fromSelector.appendChild(fromOption);

            var toSelector = document.getElementById("toId");
            var toOption = document.createElement("option");
            toOption.append(City);
            toSelector.appendChild(toOption);
        }

    })
    //catch error if api not fetch data
    .catch((error) => {
        document.getElementById("info").removeAttribute("hidden");
        setTimeout(() => {
            document.getElementById("info").setAttribute("hidden", "");
        }, 3000);
    });



//global variables for exchanging currency
let fromOption;
let toOption;
let userAmount;




//converting currency
let convert = () => {

    let userFrom = document.getElementById("fromId");
    fromOption = userFrom.options[userFrom.selectedIndex].value;
    let userTo = document.getElementById("toId");
    toOption = userTo.options[userTo.selectedIndex].value;
    userAmount = document.getElementById("userAmount").value;
    //checking user amount > 0 
    if ((fromOption != "") && (toOption != "")) {



        if (userAmount > 0) {
            var actualUrl = 'https://api.exchangeratesapi.io/latest?base=';
            //again fetch api there is base currency is selected by user
            fetch(`${actualUrl}${fromOption}`, { method: 'GET' })
                .then((response) => response.json())
                .then((dataApi) => {
                    //getting data and converting currency
                    var final = dataApi.rates[toOption];
                    final = final * Number(userAmount);
                    //showing results
                    document.getElementById("final-amount-msg").removeAttribute("hidden");
                    document.getElementById("user-amount").innerHTML = userAmount;
                    document.getElementById("msg").innerHTML = `${fromOption} is`;
                    document.getElementById("final-amount").innerHTML = final;
                    document.getElementById("msg2").innerHTML = toOption;

                    //showing exchange button
                    document.getElementById("exchange").style.display = "inline-block";



                })
        } else {
            //if else api data not fetch then showing warning for 3 seconds
            document.getElementById("warning").removeAttribute("hidden");
            document.getElementById("warning").innerHTML = " Please Enter Any Amount That You Want TO Convert";
            setTimeout(() => {
                document.getElementById("warning").setAttribute("hidden", "");
            }, 3000);
        }


    } else {
        //if else user not select any country then showing warning for 3 seconds
        document.getElementById("warning").removeAttribute("hidden");
        document.getElementById("warning").innerHTML = " Please Select Country Currency That You Want TO Convert";
        setTimeout(() => {
            document.getElementById("warning").setAttribute("hidden", "");
        }, 3000);
    }


}



let exchange = () => {


    //exchanging again and again for base city and for again fetch api 
    let holder1 = toOption;
    toOption = fromOption;
    fromOption = holder1;

    //exchanging options value
    let holder2 = document.getElementById("fromId").selectedIndex;
    document.getElementById("fromId").selectedIndex = document.getElementById("toId").selectedIndex;
    document.getElementById("toId").selectedIndex = holder2;



    var actualUrl = 'https://api.exchangeratesapi.io/latest?base=';
    //again fetch api there is base currency is selected by user
    fetch(`${actualUrl}${fromOption}`, { method: 'GET' })
        .then((response) => response.json())
        .then((dataApi) => {
            //getting data and converting currency
            var final = dataApi.rates[toOption];
            final = final * Number(userAmount);
            //showing results
            document.getElementById("final-amount-msg").removeAttribute("hidden");
            document.getElementById("user-amount").innerHTML = userAmount;
            document.getElementById("msg").innerHTML = `${fromOption} is`;
            document.getElementById("final-amount").innerHTML = final;
            document.getElementById("msg2").innerHTML = toOption;


        })


}